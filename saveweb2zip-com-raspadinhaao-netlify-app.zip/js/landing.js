// Landing page logic
document.addEventListener('DOMContentLoaded', function () {
    const landingView = document.getElementById('landing-view');
    const loginView = document.getElementById('login-view');
    const participateBtn = document.getElementById('landing-participate-btn');

    // Load landing video script only when landing view is active
    if (landingView && !landingView.classList.contains('hidden')) {
        var s = document.createElement("script");
        s.src = "https://scripts.converteai.net/3a81e1fa-41a1-48a8-a880-e2c25b1000e7/players/697ca1c67e3c196b02b70c71/v4/player.js";
        s.async = true;
        document.head.appendChild(s);
    }

    // Handle participate button click
    if (participateBtn) {
        participateBtn.addEventListener('click', function () {
            // Pause the video player
            const videoPlayer = document.querySelector('#vid-697ca1c67e3c196b02b70c71');
            if (videoPlayer && typeof videoPlayer.pause === 'function') {
                videoPlayer.pause();
            }

            // Hide landing view
            if (landingView) {
                landingView.classList.add('hidden');
                landingView.style.display = 'none';
            }

            // Show login view
            if (loginView) {
                loginView.classList.remove('hidden');
                loginView.style.display = 'flex';
            }
        });
    }
});
